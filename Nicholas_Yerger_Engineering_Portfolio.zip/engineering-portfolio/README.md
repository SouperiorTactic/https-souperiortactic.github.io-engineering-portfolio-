# Nicholas Yerger | Engineering Portfolio

A self-contained, responsive engineering portfolio template.

## Open
Open `index.html` in a browser. No build tools or server required. Google Fonts requires an internet connection; fallback fonts work offline.

## Customize
1. Update your introduction, academic details, and About section in `index.html`.
2. Search for `const projects=` near the bottom of `index.html`. Each object represents one editable project. Replace fictional projects with completed work and verified results. You can delete objects or add new ones with unique `id` values and supported `visual` types.
3. Replace the sample SVG diagrams with your own photos or figures if desired. The `drawings` object contains the placeholder art. To use an image, change the corresponding visual HTML to `<img src="images/your-photo.jpg" alt="Description" style="width:100%;height:100%;object-fit:cover">` and put your photo in an `images` folder.
4. Replace `YOUR_EMAIL@example.com` and the LinkedIn URL in the Contact section.
5. Add `resume.pdf` to this folder. Remove the `resumeLink` click handler near the end of the script so the link opens the PDF normally.
6. Update the skills list to reflect tools you have actually used.
7. Remove the sample-project warning **only after** all public-facing sample projects have been replaced with real work.

## Publish
Deploy the folder on GitHub Pages, Netlify, or another static hosting provider. Do not publish fictional project results as personal accomplishments.

## Suggested real project content
For each project, provide: problem statement, requirements, role, constraints, design/analysis methods, photos or figures, calculations, test setup, measured data, results, limitations, and lessons learned.
